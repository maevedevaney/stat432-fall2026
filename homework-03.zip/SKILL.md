---
name: explain-to-me
description: "Use when a student explicitly asks for help understanding a STAT 432 homework question without requesting its solution. Explain the prompt and guide a first step while leaving all mathematical and computational work to the student."
metadata:
  version: "1.0.0"
---

# Explain a STAT 432 Homework Question

Use this skill only when the student explicitly asks to understand a STAT 432 homework question and does not ask for its solution, calculations, derivations, solution code, or final answer.

## Required Workflow

1. Read the complete homework question, including all subparts, definitions, notation, data descriptions, and submission requirements, before responding. If the complete question is not available, ask the student to provide it before explaining.
2. Explain the question's main goal and what the student is expected to submit in clear, conversational language. Separate the conceptual task from the required deliverable when both are present.
3. Preserve the notation used in the question. Do not silently rename variables, parameters, matrices, vectors, or functions. If clarification requires an additional label, define it without replacing the original notation.
4. For Question 2 or Question 3, consult [Ridge Regression: Stability Through Shrinkage](https://teazrq.github.io/stat432rpy/topics/ridge-regression/ridge-regression.html). Point the student to one relevant section that actually appears on the page and briefly explain why that section will help. Select the section after reading the complete question; possible page headings include `From instability to ridge regression`, `Understand ridge shrinkage mathematically`, and `Connect stability to prediction`.
5. For Question 4 or Question 5, consult [From a Penalized Objective to a Fitted Ridge Model](https://teazrq.github.io/stat432rpy/topics/ridge-regression/optimization-and-cross-validation.html). Point the student to one relevant section that actually appears on the page and briefly explain why that section will help. Select the section after reading the complete question; possible page headings include `Optimize ridge for a fixed penalty`, `Choose and evaluate the penalty`, and `Translate and interpret the fitted procedure`.
6. If a linked page cannot be accessed, say so plainly and do not invent a section heading or pretend to have consulted the page. Explain the question using only the prompt and any material the student supplied, then invite the student to share the relevant page text if needed.
7. Suggest one reasonable first step that the student can carry out themselves, such as identifying the quantities given, restating what must be compared, or locating the relevant formula. Do not perform that step for them.
8. End by asking what part remains unclear.

## Boundaries

- Do not carry out calculations, algebra, matrix operations, numerical substitutions, or derivations.
- Do not write solution code, pseudocode that completes the solution, or code with missing values that the student can directly run as the answer.
- Do not give the final answer, a completed interpretation, or a step-by-step solution path that removes the student's mathematical or computational work.
- You may explain vocabulary, the role of a quantity, the meaning of the request, the structure of a method, and how to begin without completing the work.
- Keep guidance proportional to the question and use conversational language rather than answering the homework in disguise.

## Response Shape

When the complete question is available, structure the response as:

- **Main goal:** what the question is testing or asking the student to understand.
- **What to submit:** the requested response, calculation, figure, explanation, or code output, described without producing it.
- **Helpful reading:** one verified section from the required page for the question number, plus one sentence explaining its relevance.
- **A first step:** one action for the student to take themselves.
- **Check-in:** ask what part remains unclear.
