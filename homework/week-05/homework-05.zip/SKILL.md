---
name: plot-formatting
description: "Use when asked to format, polish, or improve an existing statistical plot in R or Python, including figure size, labels, ticks, margins, legends, colors, and line styles. Preserve the plotted data, calculations, and statistical meaning."
metadata:
  version: "1.0.0"
---

# STAT 432 Plot Formatting

Apply this skill when improving the presentation of an existing statistical plot. Make the smallest changes needed to its existing R or Python plotting code; do not replace the analysis or alter what the plot represents.

## Required Workflow

1. Locate the code that creates the plot and identify its data, mappings, calculations, scales, and intended audience. Read nearby code as needed to understand units, labels, and whether the figure has multiple panels.
2. Preserve the plotted data, calculations, statistical meaning, and any meaningful ordering, grouping, or transformations. Do not filter, summarize, resample, or otherwise change data to make the plot look cleaner. Do not change scales or limits in a way that hides observations or misrepresents comparisons.
3. Apply the formatting checklist below using the plotting library and style already present in the code. Keep the change focused on the existing plot.
4. Check that titles, axis labels, tick labels, and legends fit within the figure and are not clipped. Adjust margins, spacing, or layout as needed.
5. Run the narrowest available render or code check for the edited plot. If it cannot be run, state that the result was not rendered and identify what remains to be checked.
6. Briefly report the formatting changes and confirm that the data and statistical calculations were left unchanged.

## Formatting Checklist

- Preserve the plotted data, calculations, and statistical meaning.
- Leave sufficient margin for titles, axis labels, tick labels, and legends; prevent clipping and overlap.
- Use a short, informative title.
- Label axes clearly, include units when relevant, and choose readable tick spacing and labels.
- Use a colorblind-friendly palette. When curves might otherwise be difficult to distinguish, use line styles as well as color.
- Start with a figure size of 6.5 by 4.5 inches, 12-point axis labels, and a 14-point title. Adjust the figure size and layout for multiple panels so that labels, ticks, and legends remain readable.
- Apply the formatting to the existing R or Python plotting code.

## Boundaries

- Treat formatting as a presentation-only change. Do not modify the source data, statistical calculations, model, or plotted quantities.
- Preserve existing scales and transformations unless the user explicitly requests a substantive change. If a requested formatting adjustment could affect interpretation, explain the tradeoff and ask before changing it.
- Do not add decorative elements that compete with the data or make the plot harder to read.
- Keep existing project conventions and plotting-library choices; do not introduce a new dependency for routine formatting.

## Reference

The STAT 432 Week 05 example for plotting conventions is available at [Solutions: Week 05](https://teazrq.github.io/stat432rpy/practice/weeks/week-05/solutions.html#cb47-7).
